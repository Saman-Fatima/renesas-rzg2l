# meta-renesas/recipes-rzv2l

- This is a Yocto build layer that provides extra packages that only support for the RZ/V2L.
- RZ/V2L uses other packages with same configuration as RZ/G2L does in recipes-common and recipes-rzg2l.
